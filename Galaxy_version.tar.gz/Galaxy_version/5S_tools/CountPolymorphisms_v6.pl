#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
my $VERSION='0.6';
my $lastModif='2017-May-01';

my $startref=0;
my $endref;
my $meandepth=1;

my $seqNoise=10; # sequencing noise

# set the options
&GetOptions("h|help"        => \&help,
	    "startref:i"    => \$startref,		# start position of the reference sequence in the fasta sequence (default=0)
	    "endref:i"	    => \$endref,		# end position of the reference sequence in the fasta sequence
	    "meandepth:i"   => \$meandepth		# sequencing depth of the selected gene (for normalization) (default=1)
	   );

@ARGV or &help;

# check files existence
(-e "$ARGV[0]") or &help2($ARGV[0]);
(-e "$ARGV[1]") or &help2($ARGV[1]);

#########################################################################################################
#						info							#
#########################################################################################################
=head

 #DESCRIPTION
 Count all detected polymorphisms for each position
 
 # USAGE: $name [-h|--help] --startref:int --endref:int <ref.fasta> <file.sam> <output_file>

 #OPTIONS
   - startref [INT]   => start position of the reference sequence in the fasta sequence (default=0)
   - endref [INT]     => end position of the reference sequence in the fasta sequence
   - meandepth [INT]  => sequencing depth of the selected gene (for normalization) (default=1)

   - h|help           => help


 #AUTHOR
 Damien LAUBER
 Team 03 : Histone variants and the nuclear envelope in heterochromatin organization
 GReD, Genetics Reproduction & Development Lab.
 Université Clermont Auvergne
 Clermont-Ferrand, FRANCE
 http://www.gred-clermont.fr

=cut
#########################################################################################################
#						main							#
#########################################################################################################

my@tabname = split(/\//,$0);
my $scriptname = pop(@tabname);

my$out="output.txt";
if($ARGV[2]){$out=$ARGV[2];}

#############################

&main($ARGV[0],$ARGV[1],$out);

#########################################################################################################
#						SUBS							#
#########################################################################################################

sub main {

	my ($refFile,$samfile,$outfile) = @_;

	# 1/ reference sequences storing

	my%ref_seq;
	my%ref_pos_snp_nb;
	my%ref_pos_totalsnps;
	my%totalreadsByRef;
	my%normalbasebypos;
	my%ref_pos_depth;

	open (F1, "$refFile") || die ("$scriptname --sub main : pb ouverture $refFile");

	my$ref="";
	my$switch=0;

	while (my$li=<F1>) {

		if($li=~/^>/){
			chomp $li;
			$li=~s/^>//;
			$li=~s/^[\W]+//;
			$li=~s/[\W]+$//;
			$li=~s/ .+$//;

			$ref=$li;
			$switch=1;
			$ref_seq{$ref}="";
			next;
		}

		elsif ($switch==1) {
			chomp $li;
			$ref_seq{$ref}.=$li;
		}
	}
	close F1;

	foreach my$ref (keys %ref_seq){

		my@tabseq=split(//,$ref_seq{$ref});

		for (my$i=0;$i<scalar(@tabseq);$i++){

			my$pos=$i+1;
			$normalbasebypos{$ref}{$pos}=$tabseq[$i];

			$ref_pos_depth{$ref}{$pos}=0;

			if($pos>=$startref && $pos<=$endref){
				$ref_pos_totalsnps{$ref}{$pos}=0;
			}
		}
	}

	# 2/ sam file processing

	open (F2, $samfile) || die("$scriptname --sub main : pb ouverture $samfile\n");

		while (my$li=<F2>){

			next if ($li=~/^@/);								# remove the header

			chomp $li;

			my@tab=split(/\t/,$li);

			my($read,$flag,$ref,$start,$mapq,$cigar,$seq)=($tab[0],$tab[1],$tab[2],$tab[3],$tab[4],$tab[5],$tab[9]);

			$totalreadsByRef{$ref}++;

			my$res_comparaison=compareReadToRef($cigar,$start,$seq,$ref_seq{$ref});

			my$listOfSnps=trimSubseqOfSnplist($res_comparaison,$startref,$endref);

			if(defined($listOfSnps)){

				my@tab_snps= split(/;/,$listOfSnps);

				foreach my$element (@tab_snps){

					my($pos,$snp)=split(/:/,$element);

					$ref_pos_snp_nb{$ref}{$pos}{$snp}++;

					$ref_pos_totalsnps{$ref}{$pos}++;
				}
			}

			### depth increment

			my$endpos=returnEndPos($start,$cigar);

			for (my$i=$start;$i<=$endpos;$i++){

				$ref_pos_depth{$ref}{$i}++;
			}

		}
	close F2;


	# # # # # Sequencing noise clean-up

	foreach my$refc (keys %ref_pos_snp_nb){									# foreach reference sequence

		foreach my$posc (keys $ref_pos_snp_nb{$refc}){							# foreach position

			$ref_pos_totalsnps{$refc}{$posc}=0;

			foreach my$snpc (keys $ref_pos_snp_nb{$refc}{$posc}){					# pour chaque snp existant

				if ($ref_pos_snp_nb{$refc}{$posc}{$snpc}<=$seqNoise){				# if snp< noise snp=0

					#$ref_pos_snp_nb{$refc}{$posc}{$snpc}=0;

					$ref_pos_depth{$refc}{$posc}-=$ref_pos_snp_nb{$refc}{$posc}{$snpc};

					delete($ref_pos_snp_nb{$refc}{$posc}{$snpc});
				}
				else {										# else snp = snp-bruit

					$ref_pos_snp_nb{$refc}{$posc}{$snpc}-=$seqNoise;

					$ref_pos_totalsnps{$refc}{$posc}+=$ref_pos_snp_nb{$refc}{$posc}{$snpc};	# total pos += snp

					$ref_pos_depth{$refc}{$posc}-=$seqNoise;
				}
			}
		}
	}

	# # # # #

	# 3/ results printing

	open (F3, "> $outfile") || die("$scriptname --sub main : pb ouverture $outfile\n");

	foreach my$refc (sort(keys %ref_pos_totalsnps)){										# foreach reference sequence

			print F3 "reference:$refc\n";

			print F3 "position\tnumber of reads with snp\ttotal reads\t% snp";
			print F3 "\tnormalised snp\tnormalised total\tnormalised % snp";
			print F3 "\tnormal base\tsnp:number of reads\n";

			foreach my$posc (sort {$a<=>$b}(keys $ref_pos_totalsnps{$refc})){						# foreach position

				my$proportion;

				### not normalized

				if($ref_pos_depth{$refc}{$posc}>0){

					$proportion=int($ref_pos_totalsnps{$refc}{$posc}/$ref_pos_depth{$refc}{$posc}*10000)/100;	# percentage of mutated reads
				}
				else{ $proportion=0;}

				my$newpos=$posc-$startref+1;

				print F3 "$newpos\t";

				print F3 "$ref_pos_totalsnps{$refc}{$posc}\t";

				print F3 "$ref_pos_depth{$refc}{$posc}\t";

				print F3 "$proportion\t";


				### normalized


				my$newtotalsnps=int($ref_pos_totalsnps{$refc}{$posc}/$meandepth*100)/100;

				#if($newtotalsnps<1){$newtotalsnps=0;}

				my$newdepth=$ref_pos_depth{$refc}{$posc}/$meandepth;

				if($newdepth<1){$newdepth=0;}

				if($newdepth>0){

					$proportion=int($newtotalsnps/$newdepth*10000)/100;						# percentage of mutated reads
				}
				else{ $proportion=0;}

				$newdepth=int($newdepth*100)/100;

				print F3 "$newtotalsnps\t";

				print F3 "$newdepth\t";

				print F3 "$proportion\t";


				### other

				print F3 "$normalbasebypos{$refc}{$posc}";

				if(defined($ref_pos_snp_nb{$refc}{$posc})){

					foreach my$snpc (sort(keys $ref_pos_snp_nb{$refc}{$posc})){					# foreach polymorphism

						print F3 "\t$snpc:$ref_pos_snp_nb{$refc}{$posc}{$snpc}";
					}
				}


				print F3 "\n";
			}



	}
	close F3;
}

#########################################################################################################

#########################################################################################################

#########################################################################################################

sub trimSubseqOfSnplist { # remove polymorphisms out of range

	my($list,$start,$stop) = @_;

	my@tab=split(/;/,$list);

	my$result;

	foreach my$snp (@tab) {

		my$pos=$snp;

		$pos=~s/:.+$//;

		if($pos>=$start && $pos<=$stop){

			if (defined($result)&&($result ne "")) { $result.=";"; }

			$result.=$snp;
		}
	}

	return $result;
}

#########################################################################################################

sub returnEndPos { # return end position of mapped read

	my($start,$cigar)=@_;

	my$endp=$start-1;

	if ($cigar =~ m/H/){						# remove H from cigar

		$cigar =~ s/[0-9]+H//g;
	}

	if ($cigar =~ m/S/){						# remove S from cigar

		$cigar =~ s/[0-9]+S//g;
	}

	if ($cigar =~ /^([0-9]+)M$/){					# If CIGAR contains M only

		$endp+=$1;
	}

	else {
		while ($cigar ne "") {					# while CIGAR is not empty

			if ($cigar =~ m/^([0-9]+)M/){			# if starts by M

				$endp+=$1;

				$cigar =~ s/^[0-9]+M//;
			}

			elsif ($cigar =~ m/^[0-9]+I/){			# if starts by I (no end_pos shift)

				$cigar =~ s/^[0-9]+I//;
			}

			elsif ($cigar =~ m/^([0-9]+)D/){

				$endp+=$1;				# if starts by D (end_pos shifts)

				$cigar =~ s/^[0-9]+D//;
			}
		}
	}

	return $endp;

}

#########################################################################################################

#########################################################################################################

sub compareSeqToRefseq { # compares two DNA sequences

	my($seq1,$seq2,$startb)=@_; # $seq1=compared sequence,$seq2=reference sequence,$startb= start position

	my$result_b="";

	for (my$i=0;$i<length($seq1);$i++){

		my$j=$i+$startb-1;

		if (substr($seq1,$i,1) ne substr($seq2,$j,1) && substr($seq2,$j,1) ne "N") {

			if (defined($result_b)&&($result_b ne "")) { $result_b.=";"; }

			my$carac=substr($seq1,$i,1);
			my$pos=$j+1;

			$result_b.="$pos:$carac";
		}
	}

	return $result_b;
}

#########################################################################################################
#########################################################################################################


#########################################################################################################
#########################################################################################################

sub compareReadToRef {	# compares mapped read against reference sequence

	my($cigar2,$position2,$sequence2,$ref2)=@_;

	my$resultA="";

	my$currentposition=$position2;

	if ($cigar2 =~ m/H/){

		$cigar2 =~ s/[0-9]+H//g;
	}

	if ($cigar2 =~ /^[0-9]+M$/){

		$resultA=compareSeqToRefseq($sequence2,$ref2,$currentposition);
	}

	else {
		while ($cigar2 ne "") {								# while CIGAR is not empty

			if ($cigar2 =~ m/S/ || $cigar2 =~ m/I/ || $cigar2 =~ m/D/){		# If anything other than M

				if ($cigar2 =~ m/^([0-9]+)S/){					# if starts by S

					$sequence2=substr($sequence2,$1,length($sequence2));

					$cigar2 =~ s/^[0-9]+S//;

				}

				elsif ($cigar2 =~ m/^([0-9]+)M/){				# if starts by M

					my$acomparer=substr($sequence2,0,$1);

					my$int_result=compareSeqToRefseq($acomparer,$ref2,$currentposition);

					if (defined($resultA)&&($resultA ne "") && defined($int_result)&&($int_result ne "")) { $resultA.=";"; }

					$resultA.=$int_result;

					$currentposition+=$1;

					$sequence2=substr($sequence2,$1,length($sequence2));

					$cigar2 =~ s/^[0-9]+M//;
				}

				elsif ($cigar2 =~ m/^([0-9]+)I/){				# if starts by I

					if (defined($resultA)&&($resultA ne "")) { $resultA.=";"; }

					my$ajout=substr($sequence2,0,$1);

					$resultA.=$currentposition.":+".$ajout;

					$sequence2=substr($sequence2,$1,length($sequence2));

					$cigar2 =~ s/^[0-9]+I//;
				}

				elsif ($cigar2 =~ m/^([0-9]+)D/){				# if starts by D

					if (defined($resultA)&&($resultA ne "")) { $resultA.=";"; }

					my$retrait=substr($ref2,$currentposition-1,$1);

					$resultA.=$currentposition.":-".$retrait;

					$currentposition+=$1;

					$cigar2 =~ s/^[0-9]+D//;
				}
			}

			elsif ($cigar2 =~ /^[0-9]+M$/){						# if only M left

				if (defined($resultA)&&($resultA ne "")) { $resultA.=";"; }

				$resultA.=compareSeqToRefseq($sequence2,$ref2,$currentposition);

				$cigar2 =~ s/^[0-9]+M//;
			}

			else {print STDERR "sub compareReadToRef what?\n";}

		}#end while
	}#end else

	return $resultA;

}#end sub

#########################################################################################################

#########################################################################################################
sub help {
	my@tab = split(/\//,$0);
	my $name = pop(@tab);
	print STDERR <<EOF1;

 #NAME
 $name


 #DESCRIPTION
 Count all detected polymorphisms for each position


 # USAGE: $name [-h|--help] --startref:int --endref:int <ref.fasta> <file.sam> <output_file>


 #OPTIONS
   - startref [INT]   => start position of the reference sequence in the fasta sequence (default=0)
   - endref [INT]     => end position of the reference sequence in the fasta sequence
   - meandepth [INT]  => sequencing depth of the selected gene (for normalization) (default=1)

   - h|help           => help


 #UPDATE RECORD
 $lastModif  version $VERSION

EOF1
	exit(1) ;
}

sub help2 {
	my $file = shift @_;
	print STDERR "The file \"$file\" doesn't exist or is not at the specified/current location\n";
	exit(1) ;
}






# end

