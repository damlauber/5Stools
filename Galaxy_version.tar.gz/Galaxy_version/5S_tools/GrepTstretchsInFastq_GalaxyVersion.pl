#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
my $VERSION='0.3';
my $lastModif='2017-Jan-27';


my($tstretchList,$fastqFile);

# set the options
&GetOptions("h|help"    => \&help,
	    "l|list:s"	=> \$tstretchList,
	    "f|fastq:s"	=> \$fastqFile
	);


# check files
($tstretchList) or &help1("t");
($fastqFile) or &help1("f");

# check files existence
(-e "$tstretchList") or &help2($tstretchList);
(-e "$fastqFile") or &help2($fastqFile);

my$output="toto";
if(defined($ARGV[0])){$output=$ARGV[0];}

#########################################################################################################
#						info							#
#########################################################################################################
=head

 #DESCRIPTION
 Grep fastq reads containing listed T-stretchs
 Warning! ==> Can produce duplicated reads if they contain more than one Tstretch, need to be filtered!
 

 #OPTIONS
   - l|list:s	=> tstretchList input file (tabulated file, line 1 = #header, other lines = Tstretch sequence, chromosome, tstretch name[optional] [avoid blank lines])
   - f|fastq:s	=> fastq input file

   - h|help     => help


 #AUTHOR
 Damien LAUBER
 Team 03 : Histone variants and the nuclear envelope in heterochromatin organization
 GReD, Genetics Reproduction & Development Lab.
 Université Clermont Auvergne
 Clermont-Ferrand, FRANCE
 http://www.gred-clermont.fr

=cut
#########################################################################################################
#						main							#
#########################################################################################################

my %tstretch_chr; # tstretchs list : key=tstretch, value=ref chr

&readTstretchList($tstretchList);						# store tstretch list

foreach my$element (keys %tstretch_chr){					# foreach tstretch :

	&searchTstretch($tstretch_chr{$element},$element,$fastqFile,$output);	# process fastq file

}

#########################################################################################################
#						SUBS							#
#########################################################################################################

sub readTstretchList { # store tstretch list

	my $file = shift @_;

	open (F1, $file) || die("fail to open $file\n");

		while (my$li=<F1>){

			next if ($li=~/^#/);					# for header line

			chomp $li;

			my@tab=split(/\t/,$li);

			$tstretch_chr{$tab[0]}=$tab[1];				# store tstretch
		}

	close F1;
}

#########################################################################################################

sub searchTstretch { # grep on current tstretch

	my($chr,$tstretch,$file,$fileout) = @_; # tstretch chromosome, tstretch, fastq file

	`grep -B1 -A2 "$tstretch" $file | grep -v "^--\$" >> $fileout`;		# bash grep
}

#########################################################################################################

sub help {
	my@tab = split(/\//,$0);
	my $name = pop(@tab);
	print STDERR "\n";
	print STDERR <<EOF1;

 #NAME
 $name


 #DESCRIPTION
 Grep fastq reads containing listed T-stretchs
 Warning! ==> Can produce duplicated reads if they contain more than one Tstretch, need to be filtered!
 

 #OPTIONS
 required :
 - l|list:s	=> tstretchList input file (tabulated file, line 1 = #header, other lines = Tstretch sequence, chromosome, tstretch name[optional] [avoid blank lines])
 - f|fastq:s	=> fastq input file
 other :
 - h|help       => help


 #UPDATE RECORD
 $lastModif  version $VERSION

EOF1
	exit(1) ;
}

sub help1 {
	my $file = shift @_;
	print STDERR "\n";
	if ($file eq "t"){
		print STDERR "The Tstretch List file hasn't been specified in the command line\n";
	}
	else{
		print STDERR "The fastq file hasn't been specified in the command line\n";
	}
	&help;
	exit(1) ;
}

sub help2 {
	my $file = shift @_;
	print STDERR "The file \"$file\" doesn't exist or is not at the specified/current location\n";
	exit(1) ;
}






# end

