#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
my $VERSION='0.8';
my $lastModif='2016-Aug-21';
my@t = split(/\//,$0);
my $scriptname = pop(@t);

my($liminf,$limsup);
$liminf=0; # default

# set the options
&GetOptions("h|help"     => \&help,
	    "liminf:i"   => \$liminf, # start after this position (default=0)
	    "limsup:i"   => \$limsup, # end at this position
	);

# arg0 = fasta file
@ARGV or &help;

# check files existence
(-e "$ARGV[0]") or &help2($ARGV[0]);
(-e "$ARGV[1]") or &help2($ARGV[1]);

my$output="output_list.txt";
if(defined($ARGV[2])){$output=$ARGV[2];}

#########################################################################################################
#						infos							#
#########################################################################################################
=head

 #DESCRIPTION
 Detect all polymorphisms for each read for a selected interval

 #INPUTS
 - fasta reference file
 - sam file

 #OUTPUT
 txt file

 #USAGE: script.pl [-h|--help] --liminf [INT] --limsup [INT]  <reference_sequences_used_in_mapping.fasta> <mapped_reads.sam> <output.txt>

 #OPTIONS
   - liminf [INT]	=> start after this position (default=0)
   - limsup [INT]	=> end at this position

   - h|help     	=> help


 #AUTHOR
 Damien LAUBER
 Team 03 : Histone variants and the nuclear envelope in heterochromatin organization
 GReD, Genetics Reproduction & Development Lab.
 Université Clermont Auvergne
 Clermont-Ferrand, FRANCE
 http://www.gred-clermont.fr

=cut
#########################################################################################################
#						main							#
#########################################################################################################

# memorizing fasta sequences

my%ref_seq;

open (F1, "$ARGV[0]") || die("$scriptname --step open Refs : pb opening $ARGV[0]\n");

my$ref="";
my$switch=0;

while (my$li=<F1>) {

	if($li=~/^>/){
		chomp $li;
		$li=~s/^>//;
		$li=~s/^[\W]+//;
		$li=~s/[\W]+$//;
		$li=~s/ .+$//;

		$ref=$li;
		$switch=1;
		$ref_seq{$ref}="";
		next;
	}

	elsif ($switch==1) {
		chomp $li;
		$ref_seq{$ref}.=$li;

		#$switch=0;
	}
}
close F1;



#########################################################################################################




open (F2, "$ARGV[1]") || die("$scriptname --step open sam file : pb opening $ARGV[1]\n");

open (F3, ">$output") || die("$scriptname --step open output file : pb opening $output\n");

	print F3 "#reference\tread\tstart_pos\tend_pos\tPolymorphisms\n";

while (my$li=<F2>) {

	next if ($li=~/^@/);

	chomp $li;

	my@tab=split(/\t/, $li);

	# columns from sam file
	my($read,$flag,$ref,$start,$cigar,$seq)=($tab[0],$tab[1],$tab[2],$tab[3],$tab[5],$tab[9]);

	# process only mapped reads, filter by mapping flags
	if ($flag != 12 && $flag != 13 && $flag != 69 && $flag != 77 && $flag != 117 && $flag != 133 && $flag != 141 && $flag != 181 && $flag < 512 || $flag >= 1024){

		if(!(defined($ref_seq{$ref}))){print STDERR "error : no refseq available for \"$ref\"\n";}	# control, if sam file does not match with fasta

		my$res_comparaison;										# contains polymorphisms found between read & fasta

		$res_comparaison=compareReadToRef($cigar,$start,$seq,$ref_seq{$ref});

		if(defined($res_comparaison) && defined($liminf) && defined($limsup)){				# if current read has polymorphisms & an interval has been selected

			my$newres_comparaison=trimSubseqOfSnplist($res_comparaison,$liminf,$limsup);		# contains only polymorphisms for the interval

			$res_comparaison=$newres_comparaison;

		}

		my$endpos=returnEndPos($start,$cigar);								# calculate the end position of the read on fasta sequence


		if(defined($res_comparaison)){
			print F3 "$ref\t$read\t$start\t$endpos\t$res_comparaison\n"; 				# ref ; read ; start ; stop ; polymorphisms
		}

		else{
			print F3 "$ref\t$read\t$start\t$endpos\t\n"; 						# ref ; read ; start ; stop ; polymorphisms
		}

	}

}# end while

close F2;

close F3;


#########################################################################################################
#########################################################################################################

sub trimSubseqOfSnplist {	# remove polymorphisms out of range

	my($list,$start,$stop) = @_;							# list= all polymorphisms, start & stop = interval limits

	my@tab=split(/;/,$list);

	my$result;

	foreach my$snp (@tab) {

		my$pos=$snp;

		$pos=~s/:.+$//;

		if($pos>=$start && $pos<=$stop){					# if current polymorphism is in the interval

			if (defined($result)&&($result ne "")) { $result.=";"; }	# if result contains already polymorphisms => add ";"

			$result.=$snp;							# then add new polymorphism to result
		}
	}

	return $result;
}

#########################################################################################################
#########################################################################################################

sub returnEndPos { # return end position of mapped read

	my($start,$cigar)=@_;

	my$endp=$start-1;

	if ($cigar =~ m/H/){						# remove H from cigar

		$cigar =~ s/[0-9]+H//g;
	}

	if ($cigar =~ m/S/){						# remove S from cigar

		$cigar =~ s/[0-9]+S//g;
	}

	if ($cigar =~ /^([0-9]+)M$/){					# If CIGAR contains M only

		$endp+=$1;
	}

	else {
		while ($cigar ne "") {					# while CIGAR is not empty

			if ($cigar =~ m/^([0-9]+)M/){			# if starts by M

				$endp+=$1;

				$cigar =~ s/^[0-9]+M//;
			}

			elsif ($cigar =~ m/^[0-9]+I/){			# if starts by I (no end_pos shift)

				$cigar =~ s/^[0-9]+I//;
			}

			elsif ($cigar =~ m/^([0-9]+)D/){

				$endp+=$1;				# if starts by D (end_pos shifts)

				$cigar =~ s/^[0-9]+D//;
			}
		}
	}

	return $endp;

}

#########################################################################################################
#########################################################################################################

sub compareSeqToRefseq { # compares two DNA sequences, return SNP

	my($seq1,$seq2,$startb)=@_; # $seq1=compared sequence,$seq2=reference sequence,$startb= start position

	my$result_b="";

	for (my$i=0;$i<length($seq1);$i++){							# for each base of seq

		my$j=$i+$startb-1;								# current position on refseq

		if (substr($seq1,$i,1) ne substr($seq2,$j,1) && substr($seq2,$j,1) ne "N") {	# if the 2 bases ar not equal or not N

			if (defined($result_b)&&($result_b ne "")) { $result_b.=";"; }		# if result contains already an SNP => add ";"

			my$carac=substr($seq1,$i,1);						# found SNP
			my$pos=$j+1;

			$result_b.="$pos:$carac";						# add SNP to result
		}
	}

	return $result_b;
}

#########################################################################################################
#########################################################################################################

sub compareReadToRef {	# compares mapped read against reference sequence

	my($cigar2,$position2,$sequence2,$ref2)=@_;	# CIGAR, start position of the read mapped on refseq, readseq, refseq

	my$resultA="";

	my$currentposition=$position2;

	if ($cigar2 =~ m/H/){									# if Hardclipping (H)

		$cigar2 =~ s/[0-9]+H//g;							# erased from CIGAR => Hardclipped sequences are not kept in read seq
	}

	if ($cigar2 =~ /^[0-9]+M$/){								# if only M (mapped without indel)

		$resultA=compareSeqToRefseq($sequence2,$ref2,$currentposition);			# comparison of read and refseq
	}

	else {
		while ($cigar2 ne "") {								# while CIGAR is not empty

			if ($cigar2 =~ m/S/ || $cigar2 =~ m/I/ || $cigar2 =~ m/D/){		# If anything other than M

				if ($cigar2 =~ m/^([0-9]+)S/){					# if starts by S

					$sequence2=substr($sequence2,$1,length($sequence2));	# remove subseq from read seq

					$cigar2 =~ s/^[0-9]+S//;

				}

				elsif ($cigar2 =~ m/^([0-9]+)M/){						# if starts by M

					my$acomparer=substr($sequence2,0,$1);					# subseq to compare

					my$int_result=compareSeqToRefseq($acomparer,$ref2,$currentposition);	# subseq comparison result

					if (defined($resultA)&&($resultA ne "") && defined($int_result)&&($int_result ne "")) { $resultA.=";"; }

					$resultA.=$int_result;

					$currentposition+=$1;							# move current position on refseq by number of matches ($1)

					$sequence2=substr($sequence2,$1,length($sequence2));			# remove subseq from read seq

					$cigar2 =~ s/^[0-9]+M//;
				}

				elsif ($cigar2 =~ m/^([0-9]+)I/){						# if starts by I : insertion

					if (defined($resultA)&&($resultA ne "")) { $resultA.=";"; }

					my$ajout=substr($sequence2,0,$1);					# take from read seq the insert subseq

					$resultA.=$currentposition.":+".$ajout;					# add to polymorphisms list

					$sequence2=substr($sequence2,$1,length($sequence2));			# remove subseq from read seq

					$cigar2 =~ s/^[0-9]+I//;
				}

				elsif ($cigar2 =~ m/^([0-9]+)D/){						# if starts by D : deletion

					if (defined($resultA)&&($resultA ne "")) { $resultA.=";"; }

					my$retrait=substr($ref2,$currentposition-1,$1);				# take from ref seq the deleted subseq

					$resultA.=$currentposition.":-".$retrait;

					$currentposition+=$1;							# move current position on refseq by number of deleted bases

					$cigar2 =~ s/^[0-9]+D//;
				}
			}

			elsif ($cigar2 =~ /^[0-9]+M$/){								# if only M left

				if (defined($resultA)&&($resultA ne "")) { $resultA.=";"; }

				$resultA.=compareSeqToRefseq($sequence2,$ref2,$currentposition);		# add found polymorphisms

				$cigar2 =~ s/^[0-9]+M//;
			}

			else {print STDERR "sub compareReadToRef what?\n";}					# if error

		}#end while
	}#end else

	return $resultA;

}#end sub

#########################################################################################################
#						SUBS							#
#########################################################################################################

sub help {
	my@tab = split(/\//,$0);
	my $name = pop(@tab);
	print STDERR <<EOF1;

 #NAME
 $name


 #DESCRIPTION
 Detect all polymorphisms for each read for a selected interval


 #INPUTS
 - fasta reference file
 - sam file

 #OUTPUT
 txt file


 #USAGE: $name [-h|--help] --liminf [INT] --limsup [INT]  <reference_sequences_used_in_mapping.fasta> <mapped_reads.sam>


 #OPTIONS
   - liminf [INT]	=> start after this position (default=0)
   - limsup [INT]	=> end at this position

   - h|help     	=> help


 #UPDATE RECORD
 $lastModif  version $VERSION

EOF1
	exit(1) ;
}

sub help2 {
	my $file = shift @_;
	print STDERR "The file \"$file\" doesn't exist or is not at the specified/current location\n";
	exit(1) ;
}





