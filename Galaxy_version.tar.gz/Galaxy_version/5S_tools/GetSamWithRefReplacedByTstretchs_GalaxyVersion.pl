#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use SamUtils;
my $VERSION='0.5';
my $lastModif='2017-Jan-27';
my@tab = split(/\//,$0);
my $scriptname = pop(@tab);

my($refFile,$limMin,$limSup,$size,$endRef,$list,$softclip,$tstretchmode);
my$mismatches=0;

# set the options
&GetOptions("h|help"		=> \&help,
	# required
	  "r|ref:s"		=> \$refFile,		# fasta reference file
	  "m|mismatches:i"	=> \$mismatches,	# allowed mismatches betweend found tstretch & reference tstretch
	  "minstart:i"		=> \$limMin,		# the read has to map at least at this reference position or before (start <= limMin)
	  "minend:i"		=> \$limSup,		# the read has to map at least at this reference position or after (end >= limsup)
	  "size:i"		=> \$size,		# tstretchs' size
	  "endref:i"		=> \$endRef,		# references end position
	  "l|list:s"		=> \$list,		# tstretch file
	# optional
	  "t|tstretchmode"	=> \$tstretchmode,	# to have tstretch names instead of chr names in output sam
	  "S|softclip"		=> \$softclip		# if softclipping in Sam file
	);

@ARGV or &help;

# vérification de l'existence de l'arg
(-e "$ARGV[0]") or &help2($ARGV[0]);

my$output="output.sam";
if(defined($ARGV[1])){$output=$ARGV[1];}

#########################################################################################################
#						info							#
#########################################################################################################
=head

 #DESCRIPTION
 check for each read in the Sam file if is covering at least the selected interval & compare read fragment to tstretch's list in order to replace mapped reference by corresponding tstretch chr/name

 #INPUTS
 - Sam file
 - fasta reference file (-r)
 - tstretch file (-l)

 #USAGE: script.pl [options] <sam file>

 #OPTIONS
  required
   - r|ref		  => fasta reference file
   - l|list		  => tstretch file
   - m|mismatches [INT]   => allowed mismatches betweend found tstretch & reference tstretch (default=0)
   - minstart [INT]       => the read has to map at least at this reference position or before (start <= limMin) # at least start of the Tstretch!
   - minend [INT]         => the read has to map at least at this reference position or after (end >= limsup) # at least end of the Tstretch!
   - size [INT]		  => tstretchs size +1!
   - endref [INT]         => references end position


  optional
   - t|tstretchmode	=> to have tstretch names instead of chr names in output sam
   - S|softclip 	=> if softclipping in Sam file
   - h|help             => help


 #AUTHOR
 Damien LAUBER
 Team 03 : Histone variants and the nuclear envelope in heterochromatin organization
 GReD, Genetics Reproduction & Development Lab.
 Université Clermont Auvergne
 Clermont-Ferrand, FRANCE
 http://www.gred-clermont.fr

=cut
#########################################################################################################
#						main							#
#########################################################################################################



my %tstretch_chr;	# key=tstretch seq ; value=chr
my %tstretch_name;	# key=tstretch seq ; value=tstretch name


&readTstretchsList($list);

if(defined($softclip)){
	&mainWithS($ARGV[0],$refFile,$mismatches);				# if softclipping
}

else{
	&main($ARGV[0],$refFile,$mismatches);					# else
}


#########################################################################################################
#						SUBS							#
#########################################################################################################

sub main {

	my ($samfile,$refFile,$mismatches) = @_;

	my%ref_seq;		# key=reference name ; value=reference sequence
	my%tstretch_count;	# key=tstretch sequence ; value=occurences
	my$totalreads=0;	# total number of processed reads
	my$coveringreads=0;	# total number of reads reads covering selected interval


	# 1/ fasta references storage

	open (F1, "$refFile") || die ("$scriptname (main) warning : can't open $refFile");

	my$ref="";		# current reference name
	my$switch=0;		# switch

	while (my$li=<F1>) {

		if($li=~/^>/){					# if fasta name line
			chomp $li;
			$li=~s/^>//;
			$li=~s/^[\W]+//;
			$li=~s/[\W]+$//;
			$li=~s/ .+$//;

			#print STDERR "ref : $li memorised\n";	# control		

			$ref=$li;
			$switch=1;
			$ref_seq{$ref}="";
			next;
		}

		elsif ($switch==1) {				# if fasta sequence line
			chomp $li;
			$ref_seq{$ref}.=$li;
		}
	}
	close F1;

	# 2/ Sam processing

	open (F2, $samfile) || die("$scriptname (main) warning : can't open $samfile\n");

	open (F3, ">$output") || die("$scriptname --step open output file : pb opening $output\n");

		#print STDERR "file $samfile opened\n";

		while (my$li=<F2>){

			next if ($li=~/^@/);			# for sam header

			chomp $li;

			my@tab=split(/\t/,$li);

			my$read= shift @tab;				# read name
			my$flag= shift @tab;				# mapping flag
			my$ref= shift @tab;				# mapped reference name
			my$start= shift @tab;				# start position
			my$mapq= shift @tab;				# mapping quality
			my$cigar= shift @tab;				# CIGAR
			my$other1= shift @tab;					# used only for printing Sam line
			my$other2= shift @tab;					# used only for printing Sam line
			my$other3= shift @tab;					# used only for printing Sam line
			my$other= join ("\t", $other1,$other2,$other3);	# printed in output
			my$seq= shift @tab;				# read sequence
			my$last= join ("\t", @tab);			# end of sam line


			if(SamUtils::checkIfIsCoveringInterval($start,$cigar,$limMin,$limSup)){	# if read is covering the selected interval


				my$before=$endRef-$start;			# read length before the mapping start position (removed)


				my$fragment=" "; # read portion to test

				$fragment=SamUtils::extractFrag($before,$cigar,$seq,$size);	# extract read portion

				if(defined($tstretchmode)){					# if we want tstretch name in the output
					if(defined($tstretch_name{$fragment})){			# if fragment == known tstretch
						$ref=$tstretch_name{$fragment};
					}

					else{
						$ref="*";					# if fragment does not contain known tstretch
					}
				}

				else{								# if we want chr name in output
					if(defined($tstretch_chr{$fragment})){			# if fragment == known tstretch
						$ref=$tstretch_chr{$fragment};
					}

					else{
						$ref="*";					# if fragment does not contain known tstretch
					}
				}

				print F3 "$read\t$flag\t$ref\t$start\t$mapq\t$cigar\t$other\t$seq\t$last\n";	# print outpût Sam line
			}
		}

	close F3;

	close F2;

	#print STDERR "end Sam file\n";
}

#########################################################################################################

sub mainWithS { 

	my ($samfile,$refFile,$mismatches) = @_;

	my%ref_seq;		# key=reference name ; value=reference sequence
	my%tstretch_count;	# key=tstretch sequence ; value=occurences
	my$totalreads=0;	# total number of processed reads
	my$coveringreads=0;	# total number of reads reads covering selected interval


	# 1/ fasta references storage

	open (F1, "$refFile") || die ("$scriptname (mainWithS) warning : can't open $refFile");

	my$ref="";		# current reference name
	my$switch=0;		# switch

	while (my$li=<F1>) {

		if($li=~/^>/){					# if fasta name line
			chomp $li;
			$li=~s/^>//;
			$li=~s/^[\W]+//;
			$li=~s/[\W]+$//;
			$li=~s/ .+$//;

			#print STDERR "ref : $li memorised\n";	# control		

			$ref=$li;
			$switch=1;
			$ref_seq{$ref}="";
			next;
		}

		elsif ($switch==1) {				# if fasta sequence line
			chomp $li;
			$ref_seq{$ref}.=$li;
		}
	}
	close F1;

	# 2/ Sam processing

	open (F2, $samfile) || die("$scriptname (mainWithS) warning : can't open $samfile\n");

	open (F3, ">$output") || die("$scriptname --step open output file : pb opening $output\n");

		#print STDERR "file $samfile opened\n";

		while (my$li=<F2>){

			next if ($li=~/^@/);			# for sam header

			chomp $li;

			my@tab=split(/\t/,$li);

			my$read= shift @tab;				# read name
			my$flag= shift @tab;				# mapping flag
			my$ref= shift @tab;				# mapped reference name
			my$start= shift @tab;				# start position
			my$mapq= shift @tab;				# mapping quality
			my$cigar= shift @tab;				# CIGAR
			my$other1= shift @tab;					# used only for printing Sam line
			my$other2= shift @tab;					# used only for printing Sam line
			my$other3= shift @tab;					# used only for printing Sam line
			my$other= join ("\t", $other1,$other2,$other3);	# printed in output
			my$seq= shift @tab;				# read sequence
			my$last= join ("\t", @tab);			# end of sam line


			if(SamUtils::checkIfIsCoveringIntervalWithSEnd($start,$cigar,$limMin,$limSup)){	# if read is covering the selected interval


				my$before=$endRef-$start;			# read length before the mapping start position (removed)

				my$fragment=" "; # read portion to test

				$fragment=SamUtils::extractFrag($before,$cigar,$seq,$size);	# extract read portion


				if(defined($tstretchmode)){					# if we want tstretch name in the output
					if(defined($tstretch_name{$fragment})){			# if fragment == known tstretch
						$ref=$tstretch_name{$fragment};
					}

					else{
						$ref="*";					# if fragment does not contain known tstretch
					}
				}

				else{								# if we want chr name in output
					if(defined($tstretch_chr{$fragment})){			# if fragment == known tstretch
						$ref=$tstretch_chr{$fragment};
					}

					else{
						$ref="*";					# if fragment does not contain known tstretch
					}
				}

				print F3 "$read\t$flag\t$ref\t$start\t$mapq\t$cigar\t$other\t$seq\t$last\n";	# print outpût Sam line
			}
		}

	close F3;

	close F2;

	#print STDERR "end Sam file\n";
}

#########################################################################################################



sub readTstretchsList { # read tstretch file & store tstretchs => %

	my $file = shift @_;

	open (F1, $file) || die("$scriptname (readTstretchsList) warning : can't open $file\n");

		while (my$li=<F1>){

			next if ($li=~/^#/);

			chomp $li;

			my@tab=split(/\t/,$li);

			$tstretch_chr{$tab[0]}=$tab[1];	# [0]=tstretch sequence ; [1]=chromosome

			if(scalar(@tab)>2){$tstretch_name{$tab[0]}=$tab[2];} # if [2] => store in tstretch name
		}

	close F1;
}

#########################################################################################################

sub help {
	my@tab = split(/\//,$0);
	my $name = pop(@tab);
	print STDERR "\n";
	print STDERR <<EOF1;

 #NAME
 $name


 #DESCRIPTION
 check for each read in the Sam file if is covering at least the selected interval & compare read fragment to tstretch's list in order to replace mapped reference by corresponding tstretch chr/name


 #USAGE: $name [options] <sam file>


 #INPUTS
 - Sam file
 - fasta reference file (-r)
 - tstretch file (-l)


 #OPTIONS
  required
   - r|ref		  => fasta reference file
   - l|list		  => tstretch list file
   - m|mismatches [INT]   => allowed mismatches betweend found tstretch & reference tstretch (default=0)
   - minstart [INT]       => the read has to map at least at this reference position or before (start <= limMin)  # at least start of the Tstretch!
   - minend [INT]         => the read has to map at least at this reference position or after (end >= limsup) # at least end of the Tstretch!
   - size [INT]		  => tstretchs size +1!
   - endref [INT]         => references end position

  optional
   - t|tstretchmode	=> to have tstretch names instead of chr names in output sam
   - S|softclip 	=> if softclipping in Sam file (if reads longer than reference sequence)
   - h|help             => help


 #UPDATE RECORD
 $lastModif  version $VERSION

EOF1
	exit(1) ;
}


sub help2 {
	my $file = shift @_;
	print STDERR "The file \"$file\" doesn't exist or is not at the specified/current location\n";
	exit(1) ;
}




# end

