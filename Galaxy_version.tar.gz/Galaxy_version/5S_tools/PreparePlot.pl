#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
my $VERSION='0.3';
my $lastModif='2017-May-01';
my@t = split(/\//,$0);
my $scriptname = pop(@t);

my($startlim,$endlim)=(1,10000);

# set the options
&GetOptions(	"h|help"    	=> \&help,
		"startlim:i"	=> \$startlim,
		"endlim:i"	=> \$endlim
	);

@ARGV or &help;

# check files existence
(-e "$ARGV[0]") or &help2($ARGV[0]);

my$outfile=$ARGV[1];

#########################################################################################################
#						info							#
#########################################################################################################
=head

 #DESCRIPTION
 plot the polymorphisms found on reference sequence positions

 #INPUTS
 polymorphisms counts

 #USAGE: script.pl [-h|--help] --startlim:int --endlim:int <polymrophisms_counts.txt> <output_file>

 #OPTIONS
   - h|help     => help

 #AUTHOR
 Damien LAUBER
 Team 03 : Histone variants and the nuclear envelope in heterochromatin organization
 GReD, Genetics Reproduction & Development Lab.
 Université Clermont Auvergne
 Clermont-Ferrand, FRANCE
 http://www.gred-clermont.fr

=cut
#########################################################################################################
#						main						        #
#########################################################################################################

&main($ARGV[0]);

#########################################################################################################
#						SUBS							#
#########################################################################################################

sub main {

	my $file = shift @_;									# input counts file
	my$currentref="";
	my%refs;
	my%h;


# lit le fichier

	open (F1, $file) || die("$scriptname --sub subfile : pb opening F1 $file\n");

		while (my$li=<F1>){

			next if ($li=~/^position/);						# get rid of header
			next if ($li=~/^#/);							# get rid of header (in case of...)

			chomp $li;

# si référence => currentref
# %{currentref}++
			if ($li=~/^reference:(.*)$/){
				$currentref=$1;
				$refs{$currentref}++;
			}

			else{

			my@tab= split(/\t/,$li);						# columns -> @

				my$pos= shift@tab;						# position

				if($pos>=$startlim && $pos<=$endlim){				# if position within limits continue

					my$nbsnp= shift@tab;					# nb snp reads for position

					my$totalreads= shift@tab;				# nb total reads for position = depth

					my$perSnp= shift@tab;					# percentage of mutated reads for the current position

# %{pos}{currentref}=value
					$h{$pos}{$currentref}=$perSnp;
				}#endif
			}#end else
		}#end while

	close F1;

	open (F2, "> $outfile") || die("$scriptname --sub subfile : pb opening F2 $outfile\n");

		print F2 "#";

# print
# foreach sort(refc) => print refc\t
		foreach my$refc (sort(keys %refs)){
			print F2 "$refc\t\t";
		}
		print F2 "\n";

		# foreach sort(posc)
		foreach my$posc (sort{$a <=> $b}(keys %h)){
		  #foreach sort(refc)
		  foreach my$refc (sort(keys %refs)){
		    # print posc\t${posc}{refc}

			if(defined($h{$posc}{$refc})){
				print F2 "$posc\t$h{$posc}{$refc}\t";
			}
			else{print F2 "\t\t";}
		  }
		  print F2 "\n";
		}

	close F2;

}

#########################################################################################################

sub help {
	my@tab = split(/\//,$0);
	my $name = pop(@tab);
	print STDERR "\n";
	print STDERR <<EOF1;
 #NAME
 $name

 #DESCRIPTION
 plot the polymorphisms found on reference sequence positions

 #USAGE: $name [-h|--help] --startlim:int --endlim:int <polymrophisms_counts.txt> <output_file>

 #INPUTS
 polymorphisms counts

 #OPTIONS
   - h|help     => help

 #UPDATE RECORD
 $lastModif  version $VERSION

EOF1
	exit(1) ;
}

sub help2 {
	my $file = shift @_;
	print STDERR "The file \"$file\" doesn't exist or is not at the specified/current location\n";
	exit(1) ;
}






# end

