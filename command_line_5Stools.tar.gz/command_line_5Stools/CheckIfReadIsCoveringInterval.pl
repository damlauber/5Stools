#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
my $VERSION='0.5';
my $lastModif='2017-Jan-27';

my($limMin,$limSup,$softclip);

# set the options
&GetOptions("h|help"     	=> \&help,
	    "minstart:i"	=> \$limMin,		# the read has to map at least at this reference position or before (start <= limMin)
	    "minend:i"		=> \$limSup,		# the read has to map at least at this reference position or after (end >= limsup)
	    "S|softclip"	=> \$softclip		# if softclipping in Sam file
);

@ARGV or &help1;

# check files existence
(-e "$ARGV[0]") or &help2($ARGV[0]);

my$output="output.sam";
if(defined($ARGV[1])){$output=$ARGV[1];}

#########################################################################################################
#						info							#
#########################################################################################################
=head

 #DESCRIPTION
 Check for each read in the Sam file if it's covering at least the selected interval
 Warning : needs a only MAPPED READS filtered Sam file!
 
 #USAGE: script.pl [options] <sam file> <output sam file>

 #OPTIONS
   - minstart [INT]	=> the read has to map at least at this reference position or before (start <= limMin)
   - minend [INT]	=> the read has to map at least at this reference position or after (end >= limsup)
   - S|softclip	        => if softclipping in Sam file

   - h|help     => help


 #AUTHOR
 Damien LAUBER
 Team 03 : Histone variants and the nuclear envelope in heterochromatin organization
 GReD, Genetics Reproduction & Development Lab.
 Université Clermont Auvergne
 Clermont-Ferrand, FRANCE
 http://www.gred-clermont.fr

=cut
#########################################################################################################
#						main							#
#########################################################################################################

if(defined($softclip)){
	&mainWithS($ARGV[0]);				# main if softclipping in Sam file
}

else{
	&main($ARGV[0]);				# main
}

#########################################################################################################
#						SUBS							#
#########################################################################################################

sub main { # process Sam file

	my $samfile = shift @_;

	my ($totalreads,$coveringreads);							# number of processed reads, number of reads covering the interval

	open (F1, $samfile) || die("pb ouverture fichier\n");

	open (F2, ">$output") || die("--step open output file : pb opening $output\n");

		while (my$li=<F1>){

			chomp $li;

			if ($li=~/^@/){								# if sam header

				print F2 "$li\n";
			}

			else{
				$totalreads++;

				my@tab=split(/\t/,$li);

				my($read,$ref,$start,$cigar,$seq)=($tab[0],$tab[2],$tab[3],$tab[5],$tab[9]);

				if(checkIfIsCoveringInterval($start,$cigar,$limMin,$limSup)){	# if current read is covering

					$coveringreads++;

					print F2 "$li\n";					# print current line
				}
			}
		}

	close F2;

	close F1;

	# report :

	#print STDERR "total processed reads : $totalreads\n";

	#print STDERR "total covering reads :  $coveringreads\n";
}

#########################################################################################################

sub mainWithS { # process Sam file

	my $samfile = shift @_;

	my ($totalreads,$coveringreads);								# number of processed reads, number of reads covering the interval

	open (F1, $samfile) || die("pb ouverture fichier\n");

	open (F2, ">$output") || die("--step open output file : pb opening $output\n");

		while (my$li=<F1>){

			chomp $li;

			if ($li=~/^@/){									# if sam header

				print F2 "$li\n";
			}

			else{
				$totalreads++;

				my@tab=split(/\t/,$li);

				my($read,$ref,$start,$cigar,$seq)=($tab[0],$tab[2],$tab[3],$tab[5],$tab[9]);

				if(checkIfIsCoveringIntervalWithSEnd($start,$cigar,$limMin,$limSup)){	# if current read is covering

					$coveringreads++;

					print F2 "$li\n";						# print current line
				}
			}
		}

	close F2;

	close F1;

	# report :

	#print STDERR "total processed reads : $totalreads\n";

	#print STDERR "total covering reads :  $coveringreads\n";
}

#########################################################################################################

sub checkIfIsCoveringInterval {

	my($start,$cigar,$limMin,$limSup)=@_;

	my$endpos=&returnEndPos($start,$cigar);			# calculate end position of the current read

	if($start<=$limMin && $endpos>=$limSup){		# if read start & read end covering the interval

		return 1;
	}

	else { return 0;}
}

#########################################################################################################

sub checkIfIsCoveringIntervalWithSEnd {

	my($start,$cigar,$limMin,$limSup)=@_;

	my$endpos=&returnEndPosWithSEnd($start,$cigar);		# calculate end position of the current read

	if($start<=$limMin && $endpos>=$limSup){		# if read start & read end covering the interval

		return 1;
	}

	else { return 0;}
}

#########################################################################################################

sub returnEndPos { # calculate end position for the current read

	my($start,$cigar)=@_;					# start= start of read mapping, cigar= Sam CIGAR (raw 6)

	my$endp=$start-1;					# current read's end position

	if ($cigar =~ m/H/){					# remove H from cigar

		$cigar =~ s/[0-9]+H//g;
	}

	if ($cigar =~ m/S/){					# remove S from cigar

		$cigar =~ s/[0-9]+S//g;
	}

	if ($cigar =~ /^([0-9]+)M$/){				# if there remains only M

		$endp+=$1;
	}

	else {							# else
		while ($cigar ne "") {				# while CIGAR is not empty

			if ($cigar =~ m/^([0-9]+)M/){

				$endp+=$1;

				$cigar =~ s/^[0-9]+M//;
			}

			elsif ($cigar =~ m/^[0-9]+I/){		# if insertion

				$cigar =~ s/^[0-9]+I//;
			}

			elsif ($cigar =~ m/^([0-9]+)D/){

				$endp+=$1;			# if deletion

				$cigar =~ s/^[0-9]+D//;
			}
		}
	}

	return $endp;

}#end sub

#########################################################################################################

sub returnEndPosWithSEnd { # calculate end position of the current read

	my($start,$cigar)=@_;					# start= start of read mapping, cigar= Sam CIGAR (raw 6)

	my$endp=$start-1;					# current read's end position

	if ($cigar =~ m/H/){					# remove H from cigar

		$cigar =~ s/[0-9]+H//g;
	}

	if ($cigar =~ m/^[0-9]+S/){				# remove S from cigar from begining only

		$cigar =~ s/^[0-9]+S//;
	}

	if ($cigar =~ /^([0-9]+)M$/){				# if there remains only M

		$endp+=$1;
	}

	else {							# else
		while ($cigar ne "") {				# while CIGAR is not empty

			if ($cigar =~ m/^([0-9]+)M/){

				$endp+=$1;

				$cigar =~ s/^[0-9]+M//;
			}

			elsif ($cigar =~ m/^[0-9]+I/){		# if insertion

				$cigar =~ s/^[0-9]+I//;
			}

			elsif ($cigar =~ m/^([0-9]+)D/){

				$endp+=$1;			# if deletion

				$cigar =~ s/^[0-9]+D//;
			}

			elsif ($cigar =~ m/^([0-9]+)S$/){

				$endp+=$1;			# if softclipping at the end

				$cigar =~ s/^[0-9]+S$//;
			}
		}
	}

	return $endp;

}#end sub

#########################################################################################################


sub help {
	my@tab = split(/\//,$0);
	my $name = pop(@tab);
	print STDERR <<EOF1;

 #NAME
 $name


 #DESCRIPTION
 Check for each read in the Sam file if it's covering at least the selected interval
 Warning : needs a only MAPPED READS filtered Sam file!


 #USAGE: $name [options] <sam file>
 

 #OPTIONS
   - minstart [INT]	=> the read has to map at least at this reference position or before (start <= limMin)
   - minend [INT]	=> the read has to map at least at this reference position or after (end >= limsup)
   - S|softclip	        => if softclipping in Sam file

   - h|help             => help


 #UPDATE RECORD
 $lastModif  version $VERSION

EOF1
	exit(1) ;
}

sub help1 {
	my $file = shift @_;
	print STDERR "\n";
	print STDERR "The SAM file hasn't been specified in the command line\n";
	&help;
	exit(1) ;
}

sub help2 {
	my $file = shift @_;
	print STDERR "The file \"$file\" doesn't exist or is not at the specified/current location\n";
	exit(1) ;
}






# end

