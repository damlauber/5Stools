#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
my $VERSION='0.3';
my $lastModif='2017-Jan-27';

# set the options
&GetOptions("h|help"     => \&help);

@ARGV or &help;

# check files existence
(-e "$ARGV[0]") or &help2($ARGV[0]);

#########################################################################################################
#						info							#
#########################################################################################################
=head

 #DESCRIPTION
 Remove duplicated reads after grep step

 #INPUTS
 fastq file

 #OPTIONS
   - h|help     => help

 #AUTHOR
 Damien LAUBER
 Team 03 : Histone variants and the nuclear envelope in heterochromatin organization
 GReD, Genetics Reproduction & Development Lab.
 Université Clermont Auvergne
 Clermont-Ferrand, FRANCE
 http://www.gred-clermont.fr

=cut
#########################################################################################################
#						main						        #
#########################################################################################################

&subfile($ARGV[0]);				# process fastq file

#########################################################################################################
#						SUBS							#
#########################################################################################################

sub subfile { # process fastq file

	my $file = shift @_;
	my $z = 0;			# fastq line counter
	my $name = "";			# fastq read name
	my $frag = "";			# fastq read sequence
	my $score = "";			# fastq read phred score
	my %listnames;			# list of processed reads
	my $line=0;			# total fastq file processed lines
	my $printedreads = 0;		# number of unique reads
	my $notprintedreads = 0;	# number of removed duplicated reads
	my $Nreads = 0;			# number of reads containing "N" bases
	my $blanklines = 0;		# number of blank lines



	open (F1, $file) || die("pb ouverture fichier\n");

		while (my$li=<F1>){

			#next if ($li=~/^$/);

			if ($li=~/^$/){

				$blanklines++;							# if blank line found
				next;
			}

			chomp $li;

			$line++;								# processed lines +1

			if ($li=~/^@/ && $z == 0){						# if line starts by @ & counter note corresponding at score line

				if (defined($name) && $name ne"" && defined($frag) && $frag ne"" && defined($score) && $score ne""){	# if already has a previous read in memory

					if($frag!~ /N/){					# if sequence does not contain N bases

						if(!defined($listnames{$name})){		# if read is not already processed (duplicated)
							print "$name\n$frag\n+\n$score\n";	# print read in output
							$printedreads++;
						}

						else{ $notprintedreads++;}
					}

					else{ $Nreads++;}

					$listnames{$name}++;					# read retained in processed reads list
				}

				$name = "";
				$frag = "";
				$score = "";

				$z++;

				$name=$li;							# current read name
			}

			elsif ($z == 1 && $li=~/[A-Z]/){					# if on sequence line

				$z++;

				$frag=$li;
			}

			elsif ($z == 2 && $li=~/^\+$/){						# if on + line

				$z++;
			}

			elsif ($z == 3){							# if phred score line

				$z=0;

				$score=$li;
			}

			else { 
				print STDERR "warning at line $line!\n";
				print STDERR "name : $name\n";
				print STDERR "frag : $frag\n";
				print STDERR "score : $score\n";
				print STDERR "counter : $z\n";
				exit(1);
			}
		}#end while

		if (defined($name) && $name ne"" && defined($frag) && $frag ne"" && defined($score) && $score ne""){	# to print the last read

			if($frag!~ /N/){										# if sequence does not contain N bases

				if(!defined($listnames{$name})){							# if read is not already processed (duplicated)
					print "$name\n$frag\n+\n$score\n";
					$printedreads++;
				}

				else{ $notprintedreads++;}
			}

				$listnames{$name}++;
		}

	close F1;


	# report :

	my $totalreads=$line/4;

	print STDERR "$totalreads reads processed\n";
	print STDERR "$printedreads printed reads\n";
	print STDERR "$notprintedreads doublon reads\n";
	print STDERR "$Nreads ambiguous reads (N)\n";
	print STDERR "$blanklines blank lines\n";

}

#########################################################################################################

sub help {
	my@tab = split(/\//,$0);
	my $name = pop(@tab);
	print STDERR "\n";
	print STDERR <<EOF1;
 #NAME
 $name

 #DESCRIPTION
 Remove duplicated reads after grep step

 #INPUTS
 fastq file

 #OPTIONS
   - h|help     => help

 #UPDATE RECORD
 $lastModif  version $VERSION

EOF1
	exit(1) ;
}

sub help2 {
	my $file = shift @_;
	print STDERR "The file \"$file\" doesn't exist or is not at the specified/current location\n";
	exit(1) ;
}






# end

